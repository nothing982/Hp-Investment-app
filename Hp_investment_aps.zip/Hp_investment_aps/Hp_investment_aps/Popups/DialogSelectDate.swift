
import UIKit

protocol DateSelectionListener {
    func onDateSelected (date: Date, string: String)
}

class DialogSelectDate: BasePopup {

    @IBOutlet weak var date_picker: UIDatePicker!
    @IBOutlet weak var label_select_date: UILabel!
    
    var isTravelMode = false
    public var dialogTitle = "Select Date"
    public var dateType = "start"
    
    var date : Date?
    var customDate : Date?
    var minDate : Date?
    var isDateSelection = true
    var myDelegate : DateSelectionListener?
    var disableBackdate : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // For 24 Hrs
        date_picker.locale = NSLocale(localeIdentifier: "en_GB") as Locale
        initVariables()
        initUI()
        disablePreviousDate()
        
    }
    
    func initVariables () {
        if !isDateSelection {
            date_picker.datePickerMode = .time
//            date_picker.minimumDate = Date()
        } else {
            var gregorian: NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
            gregorian = NSCalendar.current as NSCalendar
            let currentDate: NSDate = NSDate()
            let components: NSDateComponents = NSDateComponents()
            
            components.year = -100
         
            date_picker.datePickerMode = UIDatePicker.Mode.dateAndTime
            
            if !disableBackdate {
                 minDate = gregorian.date(byAdding: components as DateComponents, to: currentDate as Date, options: NSCalendar.Options(rawValue: 0))!
                date_picker.minimumDate = minDate
            } else {
                if(dateType == "end"){
                    date_picker.minimumDate = minDate
                }
                else if (dateType == "start"){
                    date_picker.minimumDate = Date()
                    if(minDate != nil){
                        date_picker.maximumDate = minDate
                    }
                    
                }
                else{
                date_picker.minimumDate = Date()
                }
            }
            
            if let date = customDate {
                date_picker.setDate(customDate!, animated: true)
            }
            
            date = date_picker.date
        }
    }
    
    private func initUI () {
        label_select_date.text = dialogTitle
    }
    
    func disablePreviousDate () {
        if isTravelMode {
            if let newDate = date {
                date_picker.minimumDate = newDate
            }
        }
    }
    
    @IBAction func okOkTapped(_ sender: Any) {
//        if !isDateSelection {
//            let date = date_picker.date
//            let calendar = Calendar.current
//            let comp = calendar.dateComponents([.hour, .minute], from: date)
//            let hour = comp.hour
//            let minute = comp.minute
//            let dateFormatter = DateFormatter()
//            dateFormatter.dateFormat = "hh:mm a" // for specifying the change to format hour:minute am/pm.
//            let dateInString = dateFormatter.string(from: date)
//            print("HOUR : " , dateInString)
//        } else {
            myDelegate?.onDateSelected(date: date_picker.date, string: dateType)
            self.dismiss(animated: true, completion: nil)
//        }
    }

    
    @IBAction func onCloseTapped(_ sender: Any) {
          self.dismiss(animated: true, completion: nil)
    }
}

