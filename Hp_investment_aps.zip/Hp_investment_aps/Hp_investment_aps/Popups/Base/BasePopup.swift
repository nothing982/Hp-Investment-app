//
//  BasePopup.swift
//  Hysab Kytab
//
//  Created by MacBook Pro on 3/27/19.
//  Copyright © 2019 MacBook Pro. All rights reserved.
//

import UIKit

class BasePopup: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       initUI()
    }
    
    private func initUI () {
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(onViewTapped))
        //self.view.addGestureRecognizer(tapGesture)
    }
    
    public func animateView(popup_view: UIView) {
        popup_view.alpha = 0;
        popup_view.frame.origin.y = popup_view.frame.origin.y + 50
        UIView.animate(withDuration: 0.4, animations: { () -> Void in
            popup_view.alpha = 1.0;
            popup_view.frame.origin.y = popup_view.frame.origin.y - 50
        })
    }
    
    @objc func onViewTapped () {
        self.dismiss(animated: true, completion: nil)
    }

}
