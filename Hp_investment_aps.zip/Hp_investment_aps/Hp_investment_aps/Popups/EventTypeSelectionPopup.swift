
import UIKit

protocol EventTypeSelectionListener {
    func onTypeSelected (Type: String, Value: String, popupCat: String)
}

class EventTypeSelectionPopup: BasePopup {
    
    
    @IBOutlet weak var label_choose_transaction: UILabel!
    @IBOutlet weak var table_view_types: UITableView!
    @IBOutlet weak var view_bg: UIView!
    private let nibTypeName = "CategorySelectionViewCell"
    public var arrayOfGange = ["0 gange","1 gange","2 gange","3 gange","4 gange","5 gange","6 gange"]
    public var arrayOfTimer = ["0 timer 0 min.","0 timer 15 min.","0 timer 30 min.","0 timer 45 min.","1 timer 0 min.","1 timer 15 min.","1 timer 30 min.","1 timer 45 min.","2 timer 0 min.","2 timer 15 min.","2 timer 30 min.","2 timer 45 min.","3 timer 0 min.","3 timer 15 min.","3 timer 30 min.","3 timer 45 min.","4 timer 0 min.","4 timer 15 min.","4 timer 30 min.","4 timer 45 min.","5 timer 0 min.","5 timer 15 min.","5 timer 30 min.","5 timer 45 min.","6 timer 0 min.","6 timer 15 min.","6 timer 30 min.","6 timer 45 min.","7 timer 0 min.","7 timer 15 min.","7 timer 30 min.","7 timer 45 min.","8 timer 0 min.","8 timer 15 min.","8 timer 30 min.","8 timer 45 min.","9 timer 0 min.","9 timer 15 min.","9 timer 30 min.","9 timer 45 min.","10 timer 0 min.","10 timer 15 min.","10 timer 30 min.","10 timer 45 min.","11 timer 0 min.","11 timer 15 min.","11 timer 30 min.","11 timer 45 min.","12 timer 0 min.","12 timer 15 min.","12 timer 30 min.","12 timer 45 min.","13 timer 0 min.","13 timer 15 min.","13 timer 30 min.","13 timer 45 min.","14 timer 0 min.","14 timer 15 min.","14 timer 30 min.","14 timer 45 min."]
    public var arrayToPopulate = [String]()
    public var popupCat = ""
    public var popupType = ""
    public var popupTitle = ""
    public var bgColor = UIColor.lightGray.withAlphaComponent(0.2)
    public var delegate : EventTypeSelectionListener?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         initVariables()
        
    }
    
    private func initVariables () {
        initNibs()
        switch popupType {
        case "gange":
            arrayToPopulate = arrayOfGange
        case "timer":
            arrayToPopulate = arrayOfTimer
        default: break
            
        }
        
        table_view_types.dataSource = self
        table_view_types.delegate = self
        label_choose_transaction.text = popupTitle
        self.view_bg.backgroundColor = .white
        label_choose_transaction.textColor = .black

    }
    
    private func initNibs () {
        let nibType = UINib(nibName: nibTypeName, bundle: nil)
        table_view_types.register(nibType, forCellReuseIdentifier: nibTypeName)
    }
    
    @IBAction func onCloseTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension EventTypeSelectionPopup: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayToPopulate.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: nibTypeName, for: indexPath) as! CategorySelectionViewCell
        
        cell.label_category.text = arrayToPopulate[indexPath.row]
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard tableView.cellForRow(at: indexPath) != nil else {
            return
        }
        delegate?.onTypeSelected(Type: popupType, Value: arrayToPopulate[indexPath.row], popupCat: popupCat)
        
        self.dismiss(animated: true, completion: nil)
    }
    
}
