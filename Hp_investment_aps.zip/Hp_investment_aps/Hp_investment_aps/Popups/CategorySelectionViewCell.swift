//
//  CategorySelectionViewCell.swift
//  Hysab Kytab
//
//  Created by MacBook Pro on 4/25/19.
//  Copyright © 2019 MacBook Pro. All rights reserved.
//

import UIKit

class CategorySelectionViewCell: UITableViewCell {

    @IBOutlet weak var label_category: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
