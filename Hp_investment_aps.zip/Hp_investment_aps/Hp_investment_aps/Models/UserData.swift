//
//  UserData.swift
//  Hp_investment_aps
//
//  Created by Mehmood Ul Hassan on 11/9/21.
//

import Foundation

struct UserData : Codable {

        let id : String?
        let token : String?
        let userDisplayName : String?
        let userEmail : String?
        let userNicename : String?
        enum CodingKeys: String, CodingKey {
                case id = "id"
                case token = "token"
                case userDisplayName = "user_display_name"
                case userEmail = "user_email"
                case userNicename = "user_nicename"
        }
    
        init(from decoder: Decoder) throws {
                let values = try decoder.container(keyedBy: CodingKeys.self)
                id = try values.decodeIfPresent(String.self, forKey: .id)
                token = try values.decodeIfPresent(String.self, forKey: .token)
                userDisplayName = try values.decodeIfPresent(String.self, forKey: .userDisplayName)
                userEmail = try values.decodeIfPresent(String.self, forKey: .userEmail)
                userNicename = try values.decodeIfPresent(String.self, forKey: .userNicename)
        }

}
