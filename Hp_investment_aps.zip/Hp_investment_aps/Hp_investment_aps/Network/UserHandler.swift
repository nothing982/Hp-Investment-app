
import Foundation

class UserHandler {
    
    static let shared = UserHandler()
   
//    //MARK:- Sign In
//    class func signIn(params: [String:Any], success: @escaping(UserData)->Void, failure: @escaping(NetworkError)->Void) {
//        let url = Constants.URL.baseUrl+Constants.URL.login
//        print(url)
//        NetworkHandler.postRequest(url: url, parameters: params, success: { (successResponse) in
//            let json = JSON(successResponse)
//            let obj = UserData(fromJson: json)
//            success(obj)
//        }) { (error) in
//            failure(NetworkError(status: Constants.NetworkError.generic, message: error.message))
//        }
//    }
    
    //MARK:- Sign In
    class func signIn(params: [String:Any], success: @escaping(UserData)->Void, failure: @escaping(NetworkError)->Void) {
        let url = Constants.URL.baseUrl + Constants.URL.login
        print(url)
        NetworkHandler.postRequest(url: url, parameters: params, success: { (successResponse) in
            guard let data = successResponse.self else { return }
            do {
                let decoder = JSONDecoder()
                let obj = try decoder.decode(UserData.self, from: data as! Data)
               success(obj)
            } catch let error {
                print(error)
                failure(NetworkError(status: Constants.NetworkError.generic, message: "error.message"))
            }
        }) { (error) in
            failure(NetworkError(status: Constants.NetworkError.generic, message: error.message))
        }
    }
    //MARK:- Submit Form Data
    class func submitFormData(params: [String:Any], success: @escaping(FormData)->Void, failure: @escaping(NetworkError)->Void) {
        let url = Constants.URL.baseUrl + Constants.URL.submitform
        print(url)
        NetworkHandler.postRequest(url: url, parameters: params, success: { (successResponse) in
            guard let data = successResponse.self else { return }
            do {
                let decoder = JSONDecoder()
                let obj = try decoder.decode(FormData.self, from: data as! Data)
               success(obj)
            } catch let error {
                print(error)
                failure(NetworkError(status: Constants.NetworkError.generic, message: "error.message"))
            }
        }) { (error) in
            failure(NetworkError(status: Constants.NetworkError.generic, message: error.message))
        }
    }
}
