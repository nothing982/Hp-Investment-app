//
//  ViewController.swift
//  Hp_investment_aps
//
//  Created by Abdul Hannan on 11/6/21.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    var userData: UserData?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("main view did load ")
        username.delegate = self
        password.delegate = self
    }

    func textFieldShouldBeginEditing(_ textField: UITextField){
        print("Begin editing")
       
    }
    func inputFormVcCall(){
        let inputFormVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InputViewController") as! InputViewController
        inputFormVC.userData = self.userData
        self.navigationController?.pushViewController(inputFormVC, animated: true)
    }
    @IBAction func signInBtn(_ sender: UIButton) {
        if username.text != "" && password.text != "" {
            let param : [String : Any] = [ "username" : username.text ?? "", "password" : password.text ?? ""]
            self.loginUser(params: param)
            
        }else {
            let alert = UIAlertController(title: "", message: "Please fill all the required fields", preferredStyle: .alert)
            
            let closeAction = UIAlertAction(title: "Close", style: UIAlertAction.Style.cancel, handler: {
                action in
                print("Close")
            })
            alert.addAction(closeAction)
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    //MARK:- API Calls
    func loginUser(params: [String:Any]){
        showLoader()
        UserHandler.signIn(params: params, success: {[weak self] (successResponse) in
            self?.userData = successResponse
            UserDefaults.standard.setValue(self?.userData?.token, forKey: "userAuthToken")
            UserDefaults.standard.synchronize()
            self?.stopAnimating()
            self?.inputFormVcCall()
        }) {[weak self] (error) in
            guard let self = self else {return}
            let alert = Constants.showBasicAlertGlobal(message: error.message)
            self.presentVC(alert)
            self.stopAnimating()
        }
    }
}

