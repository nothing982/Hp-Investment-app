//
//  InputForm.swift
//  Hp_investment_aps
//
//  Created by Abdul Hannan on 11/6/21.
//

import Foundation
import UIKit
class InputViewController: UIViewController,UITextFieldDelegate {
    var check = 0
    
    var userData: UserData?
    
    var formDataIs: FormData?
    var getUser: LoginViewController?
    let timePicker = UIDatePicker()
    
    @IBOutlet weak var turnr: UITextField!
    @IBOutlet weak var tripNumber: UITextField!
    @IBOutlet weak var startdetoText: UITextField!
    @IBOutlet weak var vognNr: UILabel!
    @IBOutlet weak var vognnr: UITextField!
    @IBOutlet weak var kunde: UITextField!
    @IBOutlet weak var chauffer: UITextField!
    @IBOutlet weak var regNr: UITextField!
    @IBOutlet weak var BestiltTil: UITextField!
    @IBOutlet weak var ledsagetstart: UITextField!
    @IBOutlet weak var bestiltKl: UITextField!
    @IBOutlet weak var ledsagerslutLbl: UILabel!
    @IBOutlet weak var ledsagerslut: UITextField!
    @IBOutlet weak var korselTill: UITextField!
    @IBOutlet weak var Godsart: UITextField!
    @IBOutlet weak var korselStart: UITextField!
    @IBOutlet weak var usernamecheck: UITextField!
    @IBOutlet weak var totalIDTime: UITextField!
    @IBOutlet weak var FastPris: UISegmentedControl!
    @IBOutlet weak var hejderute: UISegmentedControl!
    
    @IBOutlet weak var Bemærkning: UITextField!
    @IBOutlet weak var oresund: UITextField!
    @IBOutlet weak var storebelt: UITextField!
    @IBOutlet weak var arsag: UITextField!
    @IBOutlet weak var Ventetid: UITextField!
    
    @IBOutlet weak var korselSlut: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startdetoText.delegate = self
        tripNumber.delegate = self
        bestiltKl.delegate = self
        ledsagetstart.delegate = self
        ledsagerslut.delegate = self
        
        usernamecheck.text = userData.self?.userNicename
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField){
        print("HEllo")
        self.openDatePicker()
        self.openTimePicker()
        
    }
    public func presentPopupView (popupView: UIViewController) {
        popupView.providesPresentationContextTransitionStyle = true
        popupView.definesPresentationContext = true
        popupView.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        popupView.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
        self.present(popupView, animated: true, completion: nil)
    }
    func calculateTheTimeDifference(time1: String, time2: String) -> String {
        var differenceStr = "0 hrs 0 min"
        var hr1:Int = 0,hr2:Int = 0,sec1:Int = 0,sec2:Int = 0
        if(time1 != "" && time1 != " "){
            let splitArry1 = time1.components(separatedBy: ":")
            hr1 = Int(splitArry1[0]) ?? 0
            sec1 = Int(splitArry1[1]) ?? 0
        }
        if(time2 != "" && time2 != " "){
            let splitArry2 = time2.components(separatedBy: ":")
            hr2 = Int(splitArry2[0]) ?? 0
            sec2 = Int(splitArry2[1]) ?? 0
        }
        
        differenceStr = "\(((hr1 - hr2) < 0) ? 0 : (hr1 - hr2)) hrs \(((sec1 - sec2) < 0) ? 0 : (sec1 - sec2)) min"
        return differenceStr
    }
    
    @IBAction func sentForm(_ sender: UIButton) {
        
        let dict = ["Tur nr/TPT": String(turnr.text!),"Start dato":String(startdetoText.text!) ]


        
      
//
//       let contentStr = "a : \(String(tripNumber.text!)), b: \(String(tripNumber.text!))"
      //  let contentArray : [String: String] = ["Tur nr/TPT" : contentStr]
        let contentArray: [String : Any] = ["Vognmand" : String(usernamecheck.text!),"Tur nr/TPT" : (String(turnr.text!)),"Start dato": startdetoText.text!,"Vognnr": vognnr.text!,"Kunde": kunde.text!,"Chauffer": chauffer.text!,"Godsart": regNr.text!, "BestiltTil": BestiltTil.text!,"Bestiltt Kl": bestiltKl.text!, "Korsel til": korselTill.text!, "Korsel Start": korselStart.text!, "Ledsaget start": ledsagetstart.text!, "Ledsager slut": ledsagerslut.text!, "Bemærkning": Bemærkning.text!,"Fastpris": "NEG", "Hejderute": "NEG","Ventitid": Ventetid.text!,"Årsag": arsag.text!,"Storebælt": storebelt.text!,"Oresund" : String(oresund.text!),"TotalTid": korselSlut.text!]
        
        if let json = try? JSONSerialization.data(withJSONObject: contentArray, options: []) {
            if let content = String(data: json, encoding: String.Encoding.utf8) {
                // here `content` is the JSON dictionary containing the String
                let param: [String : Any] = ["title": "testing2","status": "publish","content":content]
                self.submitFormData(params: param)
            }
        }

       
    }
    @IBAction func dateAndTimeSelectionTapped(_ sender: UIButton) {
        let datePopup = DialogSelectDate(nibName: "DialogSelectDate",
                                         bundle: nil)
        
        switch sender.tag {
        case 0:
            datePopup.dateType = "0"
            datePopup.dialogTitle = "Select Date"
            datePopup.isDateSelection = true
        case 1:
            datePopup.dateType = "1"
            datePopup.dialogTitle = "Select Time"
            datePopup.isDateSelection = false
        case 2:
            datePopup.dateType = "2"
            datePopup.dialogTitle = "Select Time"
            datePopup.isDateSelection = false
        case 3:
            datePopup.dateType = "3"
            datePopup.dialogTitle = "Select Time"
            datePopup.isDateSelection = false
        case 4:
            datePopup.dateType = "4"
            datePopup.dialogTitle = "Select Time"
            datePopup.isDateSelection = false
        case 5:
            datePopup.dateType = "5"
            datePopup.dialogTitle = "Select Time"
            datePopup.isDateSelection = false
        default:
            break
        }
        
        datePopup.myDelegate = self
        datePopup.minDate = nil
        self.presentPopupView(popupView: datePopup)
    }
    
    @IBAction func timerAndGangButtonTapped(_ sender: UIButton) {
        let timerAndGangePopup = EventTypeSelectionPopup(nibName: "EventTypeSelectionPopup",
                                                                  bundle: nil)
        
        
        switch sender.tag {
        case 0:
            timerAndGangePopup.popupCat = "0"
            timerAndGangePopup.popupTitle = "Select"
            timerAndGangePopup.popupType = "timer"
        case 1:
            timerAndGangePopup.popupCat = "1"
            timerAndGangePopup.popupTitle = "Select Gange"
            timerAndGangePopup.popupType = "gange"
        case 2:
            timerAndGangePopup.popupCat = "2"
            timerAndGangePopup.popupTitle = "Select Gange"
            timerAndGangePopup.popupType = "gange"
        default:
            break
        }
        
        timerAndGangePopup.delegate = self
        self.presentPopupView(popupView: timerAndGangePopup)
    }
    
    //MARK:- API Calls
    func submitFormData(params: [String:Any]){
        showLoader()
        UserHandler.submitFormData(params: params, success: {[weak self] (successResponse) in
            self?.formDataIs = successResponse
            self?.stopAnimating()
            let alert = Constants.showBasicAlertGlobal(message: "Successfully Submitted.")
            self?.presentVC(alert)
//            self?.inputFormVcCall()
        }) {[weak self] (error) in
            guard let self = self else {return}
            let alert = Constants.showBasicAlertGlobal(message: error.message)
            self.presentVC(alert)
            self.stopAnimating()
        }
    }
}


extension InputViewController {
   
    
    
    func openTimePicker(){
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneBtnClicked))
        toolbar.items = [doneBtn]
        bestiltKl.inputAccessoryView = toolbar
        bestiltKl.inputView = timePicker
        timePicker.datePickerMode = .time
        
    }
    
    
    @objc func doneBtnClicked(){
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        bestiltKl.text = formatter.string(from: timePicker.date)
        self.view.endEditing(true)
    }
    
    
    func openDatePicker(){
        let datePicker = UIDatePicker()
        
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
        startdetoText.inputView = datePicker
        
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 44))
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelBtnClick))
        let felxibleButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .done
                                         , target: self, action: #selector(self.doneBtnClick))
        toolbar.setItems([cancelButton,felxibleButton, doneButton ], animated : false)
        startdetoText.inputAccessoryView = toolbar
    }
    
  
    @objc
    func cancelBtnClick(){
        startdetoText.resignFirstResponder()
    }
    
    @objc func doneBtnClick(){
        if let datePicker = startdetoText.inputView as? UIDatePicker{
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            startdetoText.text = dateFormatter.string(from: datePicker.date)
            print(datePicker.date)
        }
        startdetoText.resignFirstResponder()
    }
    
    @objc
    func datePickerHandler(datePicker: UIDatePicker){
        print(datePicker.date)
        
    }
}

extension InputViewController: DateSelectionListener,EventTypeSelectionListener {
    func onTypeSelected(Type: String, Value: String, popupCat: String) {
        switch popupCat {
        case "0":
            Ventetid.text = Value
        case "1":
            storebelt.text = Value
        case "2":
            oresund.text = Value
        default:
            break
        }
    }
    
    func onDateSelected(date: Date, string: String) {
        
        let strTime = date.dateStringWith(strFormat: "HH:mm")
        let strDate = date.dateToString()
        print("\(date)..\(string)..\(strTime)")
        
        switch string {
        case "0":
            startdetoText.text = strDate
        case "1":
            bestiltKl.text = strTime
        case "2":
            korselStart.text = strTime
            totalIDTime.text = calculateTheTimeDifference(time1: korselSlut.text ?? "", time2: korselStart.text ?? "")
        case "3":
            ledsagetstart.text = strTime
        case "4":
            ledsagerslut.text = strTime
        case "5":
            korselSlut.text = strTime
            totalIDTime.text = calculateTheTimeDifference(time1: korselSlut.text ?? "", time2: korselStart.text ?? "")
        default:
            break
        }
    }
    
    
}
// Extension of Date
extension Date {
    func dateStringWith(strFormat: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = Calendar.current.timeZone
        dateFormatter.locale = Calendar.current.locale
        dateFormatter.dateFormat = strFormat
        return dateFormatter.string(from: self)
    }
    func dateToString() -> String {
        let stringDate : String
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        stringDate = dateFormatter.string(from: self)
        return stringDate
    }
}
